package es.urjc.code.ejem1.domain.service;

import java.util.Collection;

import es.urjc.code.ejem1.domain.dto.FullShoppingCartValueDTO;

public interface ShoppingCartValueService {

    public Collection<FullShoppingCartValueDTO> getShoppingCartValues() ;

}
